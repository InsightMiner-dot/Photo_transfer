import cv2
import pytesseract
import os
import pandas as pd

# Set TESSDATA_PREFIX to the directory containing language data files
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

# Specify the input video file and output directory
input_video = r"C:\Users\ankan\Downloads\Car-Number-Plates-Detection-main\Car-Number-Plates-Detection-main\sample.mp4"  # Provide the path to the input video
output_folder = r"Car-Number-Plates-Detection-main/output_from_video"  # Provide the path to the output folder
output_cropped_images_folder = os.path.join(output_folder,
                                            "cropped2_images")  # Folder to store cropped number plate images
output_excel_file = "extracted_text.xlsx"  # Specify the name of the Excel file

# Create the output folders if they don't exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

if not os.path.exists(output_cropped_images_folder):
    os.makedirs(output_cropped_images_folder)

harcascade = "model/indian_license_plate.xml"

# Open the video file for capturing frames
cap = cv2.VideoCapture(input_video)

frame_number = 0  # Initialize frame number

# Initialize lists to store extracted text, frame associations, and timestamps
frame_associations = []
extracted_text_list = []
timestamps = []

# Create a window to display the video
cv2.namedWindow('Video Preview', cv2.WINDOW_NORMAL)
cv2.resizeWindow('Video Preview', 800, 600)

while cap.isOpened():
    ret, frame = cap.read()

    if not ret:
        break

    frame_number += 1  # Increment frame number

    min_area = 500

    plate_cascade = cv2.CascadeClassifier(harcascade)
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    plates = plate_cascade.detectMultiScale(frame_gray, 1.1, 4)

    for (x, y, w, h) in plates:
        area = w * h

        if area > min_area:
            img_roi = frame[y:y + h, x:x + w]

            # Save the cropped image to the output folder
            filename = os.path.join(output_cropped_images_folder, f"frame{frame_number}_crop.jpg")
            cv2.imwrite(filename, img_roi)

            # Preprocess the cropped frame (e.g., resize and threshold)
            processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
            processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
            _, processed_img = cv2.threshold(processed_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

            # Perform text extraction using Tesseract on the preprocessed image
            extracted_text = pytesseract.image_to_string(processed_img)
            extracted_text_list.append(extracted_text)
            frame_associations.append(frame_number)  # Associate with the frame number
            timestamps.append(cap.get(cv2.CAP_PROP_POS_MSEC))  # Store timestamp in milliseconds

    # Display the video frame with detected license plates
    cv2.imshow('Video Preview', frame)

    # Break the loop if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object
cap.release()

# Destroy the window
cv2.destroyAllWindows()

# Create a DataFrame to store extracted text, frame associations, and timestamps
data = {
    'Frame Number': frame_associations,
    'Timestamp (ms)': timestamps,
    'Extracted Text': extracted_text_list
}
df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
df.to_excel(os.path.join(output_folder, output_excel_file), index=False)

print(f"Extracted text saved to {output_folder}/{output_excel_file}")
print(f"Cropped number plate images saved to {output_cropped_images_folder}")
