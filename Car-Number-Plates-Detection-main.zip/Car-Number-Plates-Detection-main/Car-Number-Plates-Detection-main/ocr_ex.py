# installation
# !pip install keras-ocr -q

import keras_ocr

pipeline = keras_ocr.pipeline.Pipeline()
extract_info = pipeline.recognize([r"D:\Number_Plate\New folder\N01_crop1"])
print(extract_info[0][0])