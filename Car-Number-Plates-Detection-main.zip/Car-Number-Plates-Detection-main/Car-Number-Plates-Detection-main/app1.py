import streamlit as st
import cv2
import pytesseract
import os
import numpy as np

def main():
    st.title("License Plate Recognition App")

    # Set TESSDATA_PREFIX to the directory containing language data files
    os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

    harcascade = r"C:\Users\ankan\Downloads\Car-Number-Plates-Detection-main\Car-Number-Plates-Detection-main\model\indian_license_plate.xml"

    image_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

    if image_file is not None:
        # Load the image
        image = cv2.imdecode(np.fromstring(image_file.read(), np.uint8), cv2.IMREAD_COLOR)

        min_area = 500
        count = 0

        plate_cascade = cv2.CascadeClassifier(harcascade)
        img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

        for (x, y, w, h) in plates:
            area = w * h

            if area > min_area:
                cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(image, "Number Plate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)

                img_roi = image[y:y + h, x:x + w]

                # Preprocess the cropped image (e.g., resize and threshold)
                processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
                processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
                _, processed_img = cv2.threshold(processed_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

                # Generate unique key for the button using count
                button_key = f"extract_button_{count}"

                if st.button("Extract Text", key=button_key):
                    # Perform text extraction using Tesseract on the preprocessed image
                    extracted_text = pytesseract.image_to_string(processed_img)
                    st.write("Extracted Text:", extracted_text)

                # Display the processed image
                st.image(processed_img, channels="GRAY")

                count += 1

        # Display the original image with license plate detection
        st.image(image, channels="BGR")

if __name__ == '__main__':
    main()
