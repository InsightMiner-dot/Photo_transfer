import cv2
import numpy as np
import torch
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.transforms import functional as F
from PIL import Image, ImageDraw
import pytesseract

# Load your local image
image_path = r'D:\Car_count\car_traffic_1.jpg'  # Replace with the path to your local image

# Load the car detection model
car_model = fasterrcnn_resnet50_fpn(pretrained=True)
car_model.eval()

# Load the license plate detection model (you need a trained model for this)
# Example: license_plate_model = load_license_plate_detection_model()

# Load the image using OpenCV
img = cv2.imread(image_path)

# Resize the image for display
display_width = 800
display_height = 600
img = cv2.resize(img, (display_width, display_height))

# Convert to a PyTorch tensor
img = F.to_tensor(img).unsqueeze(0)

# Perform car detection
with torch.no_grad():
    car_predictions = car_model(img)

car_boxes = car_predictions[0]['boxes']
car_scores = car_predictions[0]['scores']

# Set a confidence threshold for car detection
car_threshold = 0.7
car_indices = car_scores > car_threshold
car_boxes = car_boxes[car_indices]

# Initialize an empty list to store license plate texts
license_plate_texts = []

# Loop through each detected car
for car_box in car_boxes:
    # Crop the car region
    x1, y1, x2, y2 = car_box.tolist()
    car_region = img[0, :, int(y1):int(y2), int(x1):int(x2)]


    # Apply license plate detection (replace with your license plate detection code)
    # license_plate_boxes = detect_license_plate(car_region)

    # Assuming you have license plate detection boxes, loop through them
    # for license_plate_box in license_plate_boxes:
    #     x1, y1, x2, y2 = license_plate_box.tolist()
    #     license_plate_region = car_region[:, int(y1):int(y2), int(x1):int(x2)]

    #     # Perform OCR to extract text from the license plate region
    #     license_plate_pil = F.to_pil_image(license_plate_region)
    #     extracted_text = pytesseract.image_to_string(license_plate_pil)

    #     license_plate_texts.append(extracted_text)

# Display the image with car bounding boxes
img_pil = F.to_pil_image(img[0])
draw = ImageDraw.Draw(img_pil)

for car_box in car_boxes:
    x1, y1, x2, y2 = car_box.tolist()
    draw.rectangle([x1, y1, x2, y2], outline="green", width=2)

# Display the image with car bounding boxes
img_np = np.array(img_pil)

cv2.putText(img_np, f'Cars Detected: {len(car_boxes)}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
cv2.imshow('Car Detection', img_np)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Print the extracted license plate texts
for i, text in enumerate(license_plate_texts):
    print(f'License Plate {i + 1}: {text}')
