import cv2
import pytesseract
import os

# Set TESSDATA_PREFIX to the directory containing language data files
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

harcascade = "model/indian_license_plate.xml"
image_file = r"D:\Number_Plate\N11.jpg"   # Provide the path to your image file

# Load the image
img = cv2.imread(image_file)

min_area = 500
count = 0

plate_cascade = cv2.CascadeClassifier(harcascade)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

for (x, y, w, h) in plates:
    area = w * h

    if area > min_area:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(img, "Number Plate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)

        img_roi = img[y:y + h, x:x + w]
        cv2.imshow("ROI", img_roi)

        # Preprocess the cropped image (e.g., resize and threshold)
        processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
        processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
        _, processed_img = cv2.threshold(processed_img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        if cv2.waitKey(0) & 0xFF == ord('s'):
            filename = "plates/scaned_img_" + str(count) + ".jpg"
            cv2.imwrite(filename, processed_img)

            # Perform text extraction using Tesseract on the preprocessed image
            extracted_text = pytesseract.image_to_string(processed_img)
            print("Extracted Text:", extracted_text)

            count += 1

cv2.imshow("Result", img)
cv2.waitKey(0)
