import streamlit as st
import cv2
import pytesseract
import os
import pandas as pd
import numpy as np

# Set TESSDATA_PREFIX to the directory containing language data files
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'
harcascade=r"C:\Users\ankan\Downloads\Car-Number-Plates-Detection-main\Car-Number-Plates-Detection-main\model\haarcascade_russian_plate_number.xml"
# Create the Streamlit web app
st.title("License Plate Text Extraction")

# Create a sidebar for user input
st.sidebar.subheader("Input Options")
input_option = st.sidebar.radio("Choose Input Type", ["Single Image", "Image Folder"])

if input_option == "Single Image":
    # Upload a single image
    uploaded_image = st.file_uploader("Upload a single image", type=["jpg", "jpeg", "png"])

    if uploaded_image is not None:
        # Load the image
        img = cv2.imdecode(np.frombuffer(uploaded_image.read(), np.uint8), cv2.IMREAD_COLOR)
        st.image(img, use_column_width=True, caption="Uploaded Image")

        # Process the image as in your original code
        min_area = 500
        plate_cascade = cv2.CascadeClassifier("model/haarcascade_russian_plate_number.xml")
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        plates = plate_cascade.detectMultiScale(img_gray, 2.5, 4)
        count = 1
        image_file_associations = []
        extracted_text_list = []
        confidence_list = []

        for (x, y, w, h) in plates:
            area = w * h
            if area > min_area:
                img_roi = img[y:y + h, x:x + w]
                processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
                processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
                processed_img = cv2.adaptiveThreshold(processed_img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 15)
                processed_img = cv2.GaussianBlur(processed_img, (5, 5), 0)

                if cv2.countNonZero(processed_img) > 0:
                    extracted_data = pytesseract.image_to_data(processed_img, config='--psm 6', output_type=pytesseract.Output.DICT)

                    for i in range(len(extracted_data['text'])):
                        if int(extracted_data['conf'][i]) > -1:
                            extracted_text = extracted_data['text'][i]
                            confidence = extracted_data['conf'][i]

                            extracted_text_list.append(extracted_text)
                            confidence_list.append(confidence)
                            image_file_associations.append("Single Image")

                    filename = f"single_image_crop{count}.jpg"
                    st.image(processed_img, use_column_width=True, caption=f"Extracted Text: {extracted_text}", format="JPEG")
                    count += 1

        if extracted_text_list:
            st.subheader("Extracted Text and Confidence for Single Image:")
            st.write(f"Extracted Text: {extracted_text_list[0]}")
            st.write(f"Confidence Level: {confidence_list[0]}")

elif input_option == "Image Folder":
    # Upload a folder of images
    input_folder = st.file_uploader("Upload a folder of images", type=["jpg", "jpeg", "png"], accept_multiple_files=True)

    if input_folder is not None:
        # Specify the output folder and Excel file
        output_folder = "output"
        output_excel_file = "extracted_text.xlsx"

        # Create the output folder if it doesn't exist
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Process the images in the folder as in your original code
        harcascade = "model/haarcascade_russian_plate_number.xml"
        image_files = [f for f in input_folder]
        image_file_associations = []
        extracted_text_list = []
        confidence_list = []

        for uploaded_image in input_folder:
            img = cv2.imdecode(np.frombuffer(uploaded_image.read(), np.uint8), cv2.IMREAD_COLOR)
            min_area = 500
            plate_cascade = cv2.CascadeClassifier(harcascade)
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)
            count = 1

            for (x, y, w, h) in plates:
                area = w * h
                if area > min_area:
                    img_roi = img[y:y + h, x:x + w]
                    processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
                    processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
                    processed_img = cv2.adaptiveThreshold(processed_img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 15)
                    processed_img = cv2.GaussianBlur(processed_img, (5, 5), 0)

                    if cv2.countNonZero(processed_img) > 0:
                        extracted_data = pytesseract.image_to_data(processed_img, config='--psm 6', output_type=pytesseract.Output.DICT)

                        for i in range(len(extracted_data['text'])):
                            if int(extracted_data['conf'][i]) > -1:
                                extracted_text = extracted_data['text'][i]
                                confidence = extracted_data['conf'][i]

                                extracted_text_list.append(extracted_text)
                                confidence_list.append(confidence)
                                image_file_associations.append(uploaded_image.name)

                        filename = os.path.join(output_folder, f"{os.path.splitext(uploaded_image.name)[0]}_crop{count}.jpg")
                        cv2.imwrite(filename, processed_img)
                        count += 1

        st.write("Results for image folder:")
        # Display results, such as extracted text and confidence
        # ...

        # Create a DataFrame to store extracted text, confidence levels, and image file associations
        data = {'Image File': image_file_associations, 'Extracted Text': extracted_text_list, 'Confidence Level': confidence_list}
        df = pd.DataFrame(data)

        # Save the DataFrame to an Excel file
        excel_file_path = os.path.join(output_folder, output_excel_file)
        df.to_excel(excel_file_path, index=False)

        st.success(f"Extracted text with confidence levels saved to {excel_file_path}")

st.sidebar.text("By Your Name")
