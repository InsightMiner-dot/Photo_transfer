import cv2
import pytesseract
import os
import pandas as pd

# Set TESSDATA_PREFIX to the directory containing language data files
os.environ['TESSDATA_PREFIX'] = r'C:\Program Files\Tesseract-OCR\tessdata'

# Specify the input and output directories
input_folder = r"D:\Number_Plate"  # Provide the path to the input image folder
output_folder = r"D:\Number_Plate\New folder"  # Provide the path to the output folder
output_excel_file = "extracted_text.xlsx"  # Specify the name of the Excel file

# Create the output folder if it doesn't exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

harcascade = "model/haarcascade_russian_plate_number.xml"

# Get a list of image files in the input folder
image_files = [f for f in os.listdir(input_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

# Initialize lists to store extracted text, confidence levels, and image file associations
image_file_associations = []
extracted_text_list = []
confidence_list = []

for image_file in image_files:
    # Load the image
    img = cv2.imread(os.path.join(input_folder, image_file))

    min_area = 500

    plate_cascade = cv2.CascadeClassifier(harcascade)

    # Convert the image to grayscale
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

    count = 1

    for (x, y, w, h) in plates:
        area = w * h

        if area > min_area:
            img_roi = img[y:y + h, x:x + w]

            # Preprocess the cropped image
            processed_img = cv2.resize(img_roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
            processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2GRAY)
            processed_img = cv2.adaptiveThreshold(processed_img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 15)
            processed_img = cv2.GaussianBlur(processed_img, (5, 5), 0)

            if cv2.countNonZero(processed_img) > 0:
                # Perform text extraction using Tesseract with confidence
                extracted_data = pytesseract.image_to_data(processed_img, config='--psm 6', output_type=pytesseract.Output.DICT)

                for i in range(len(extracted_data['text'])):
                    if int(extracted_data['conf'][i]) > -1:
                        extracted_text = extracted_data['text'][i]
                        confidence = extracted_data['conf'][i]

                        extracted_text_list.append(extracted_text)
                        confidence_list.append(confidence)
                        image_file_associations.append(image_file)

                # Save the cropped image to the output folder
                filename = os.path.join(output_folder, f"{os.path.splitext(image_file)[0]}_crop{count}.jpg")
                cv2.imwrite(filename, processed_img)

                count += 1

# Create a DataFrame to store extracted text, confidence levels, and image file associations
data = {'Image File': image_file_associations, 'Extracted Text': extracted_text_list, 'Confidence Level': confidence_list}
df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
df.to_excel(os.path.join(output_folder, output_excel_file), index=False)

print(f"Extracted text with confidence levels saved to {output_folder}/{output_excel_file}")
