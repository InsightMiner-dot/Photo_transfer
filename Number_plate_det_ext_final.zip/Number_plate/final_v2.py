import streamlit as st
import os
import cv2
import streamlit as st
import pandas as pd
import re
import easyocr
from tempfile import NamedTemporaryFile
import numpy as np
from PIL import Image
import base64
# Define the met
# Define the page functions
def page_number_plate():
    st.title("Number Plate Extraction")
    # Add the code for number plate extraction here
    def method_1(args):
        gray = args
        reader = easyocr.Reader(['en'])
        result = reader.readtext(gray)

        def extract_alphanumeric(text):
            return re.sub(r'[^a-zA-Z0-9]', '', text)

        for detection in result:
            text = detection[1]
            confidence = detection[2]
            cleaned_text = extract_alphanumeric(text)
        alphanumeric_items = [extract_alphanumeric(item[1]) for item in result]

        pattern1 = r"^[A-Za-z]{2}[0-9]{1}[A-Za-z]{3}[0-9]{4}$"
        pattern2 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{3}[0-9]{4}$"
        pattern3 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}$"
        pattern4 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{1}[0-9]{4}$"
        pattern5 = r"^[A-Z]{2}[0-9]{2}[A-Z]{3}[0-9]{4}$"
        pattern6 = r"^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$"
        pattern7 = r"^[A-Z]{2}[0-9]{2}[A-Z]{1}[0-9]{4}$"
        matching_items = []
        for item in alphanumeric_items:
            if re.search(pattern1, item) or re.search(pattern2, item) or re.search(pattern3, item) or re.search(
                    pattern4, item) or re.search(pattern5, item) or re.search(pattern6, item) or re.search(pattern7,
                                                                                                           item):
                matching_items.append(item)
        return matching_items

    def method_2(args):
        img = args
        blurred = cv2.GaussianBlur(img, (5, 5), 0)
        # Convert the image to grayscale
        gray = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)
        _, thresholded = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        kernel = np.ones((3, 3), np.uint8)
        eroded = cv2.morphologyEx(thresholded, cv2.MORPH_ERODE, kernel, iterations=1)
        dilated = cv2.morphologyEx(eroded, cv2.MORPH_DILATE, kernel, iterations=1)
        reader = easyocr.Reader(['en'])
        result = reader.readtext(dilated)

        def extract_alphanumeric(text):
            return re.sub(r'[^a-zA-Z0-9]', '', text)

        for detection in result:
            text = detection[1]
            confidence = detection[2]
            cleaned_text = extract_alphanumeric(text)
        alphanumeric_items = [extract_alphanumeric(item[1]) for item in result]
        pattern1 = r"^[A-Za-z]{2}[0-9]{1}[A-Za-z]{3}[0-9]{4}$"
        pattern2 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{3}[0-9]{4}$"
        pattern3 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}$"
        pattern4 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{1}[0-9]{4}$"
        pattern5 = r"^[A-Z]{2}[0-9]{2}[A-Z]{3}[0-9]{4}$"
        pattern6 = r"^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$"
        pattern7 = r"^[A-Z]{2}[0-9]{2}[A-Z]{1}[0-9]{4}$"

        matching_items = []
        for item in alphanumeric_items:
            if re.search(pattern1, item) or re.search(pattern2, item) or re.search(pattern3, item) or re.search(
                    pattern4, item) or re.search(pattern5, item) or re.search(pattern6, item) or re.search(pattern7,
                                                                                                           item):
                matching_items.append(item)
        return matching_items

    # Define a function to extract number plates
    # Define a function to extract number plates
    # Define a function to extract number plates
    def extract_number_plates(uploaded_image):
        image_name = uploaded_image.name
        # Since you can't directly use an UploadedFile with OpenCV, save it to a temporary file
        with NamedTemporaryFile(delete=False, suffix=".jpg") as temp_file:
            temp_file.write(uploaded_image.read())
            image_path = temp_file.name

        img = cv2.imread(image_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        function_1 = method_1(gray)
        function_2 = method_2(img)

        return image_name, function_1, function_2

    # Create a Streamlit app

    # st.title("Number Plate Extraction")

    # Upload an image
    uploaded_image = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

    if uploaded_image:
        image_name, function_1, function_2 = extract_number_plates(uploaded_image)

        st.subheader("Uploaded Image:")
        st.image(uploaded_image, caption="Uploaded Image", use_column_width=True)

        # Initialize result DataFrame with columns
        result_df = pd.DataFrame(columns=['Image Name', 'Number Plate'])

        # Create a list to store non-'N/A' results
        non_na_results = []

        # Check if function_1 has a result other than 'N/A', and store it
        if any(result != 'N/A' for result in function_1):
            non_na_results.extend(function_1)

        # Check if function_2 has a result other than 'N/A', and store it
        if any(result != 'N/A' for result in function_2):
            non_na_results.extend(function_2)

        # Add the image name and the non-'N/A' results to a temporary DataFrame
        if non_na_results:
            temp_df = pd.DataFrame({'Image Name': [image_name], 'Number Plate': ', '.join(non_na_results)})
            # Concatenate the temporary DataFrame to the main result_df
            result_df = pd.concat([result_df, temp_df], ignore_index=True)

        # Display the DataFrame in the sidebar
        st.sidebar.subheader("Result DataFrame:")
        st.sidebar.write(result_df)

        # Add a download button for the DataFrame
        csv = result_df.to_csv(index=False)
        b64 = base64.b64encode(csv.encode()).decode()
        st.sidebar.markdown(f"Download the DataFrame as a CSV file:")
        href = f'<a href="data:file/csv;base64,{b64}" download="result_dataframe.csv">Download CSV</a>'
        st.sidebar.markdown(href, unsafe_allow_html=True)


def page_vehicle_details():
    import streamlit as st
    import pandas as pd
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options
    from selenium.common.exceptions import TimeoutException
    import warnings
    st.title("Vehicle Details Scraper")

    # Filter out DeprecationWarnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    # Create ChromeOptions object and set the executable path
    chrome_options = Options()
    chrome_options.binary_location = r"D:\Machine_Learning\numberplate_extraction\chromedriver-win32\chromedriver.exe"  # Path to Chrome executable
    chrome_options = Options()

    # Initialize the Streamlit app
    # st.title("Vehicle Details Scraper")

    # Upload an Excel file with vehicle details
    uploaded_file = st.file_uploader("Upload an Excel or CSV file with vehicle details", type=["xlsx", "csv"])

    if uploaded_file is not None:
        # Check the file type
        if uploaded_file.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':  # Excel file (.xlsx)
            vehicle_details = pd.read_excel(uploaded_file)
        elif uploaded_file.type == 'text/csv':  # CSV file (.csv)
            vehicle_details = pd.read_csv(uploaded_file)
        else:
            st.error("Unsupported file format. Please upload an Excel (.xlsx) or CSV (.csv) file.")
            st.stop()  # Stop execution if the file type is unsupported

    # User input for a single number plate
    single_number_plate = st.text_input("Enter a single Number Plate:")

    if uploaded_file is not None:
        vehicle_details = pd.read_excel(uploaded_file)

        # Function to scrape vehicle details
        def find_details(vehicle_details):
            driver = webdriver.Chrome(options=chrome_options)
            for i in range(len(vehicle_details)):
                vehicle_number = vehicle_details.at[i, "Number_Plate"]
                driver.get("https://www.acko.com/rto/how-to-check-vehicle-owner-details-by-number-plate/")
                WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "carNumber"))).send_keys(
                    vehicle_number)
                driver.find_element(By.XPATH, '//button[text()="Check Now"]').click()
                try:
                    element = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, '/html/body/div[1]/div/div[3]/div/div[2]/div/div/div/div[1]/div')))
                    data = element.text
                except TimeoutException:
                    continue

                vehicle_details.at[i, 'Car_Model'] = data.split("\n")[0]
                vehicle_details.at[i, 'Fuel_type'] = data.split("\n")[3].split("•")[1]
                vehicle_details.at[i, 'Registration_date_RC'] = data.split("\n")[3].split("•")[2]

            driver.quit()
            return vehicle_details

        # Scrape and update data for batch processing
        updated_vehicle_details = find_details(vehicle_details)

        # Display the updated data for batch processing
        st.write("Updated Vehicle Details for Batch Processing:")
        st.write(updated_vehicle_details)
        # Save the updated data to an Excel (XLSX) file
        excel_file = updated_vehicle_details.to_excel("updated_data.xlsx", index=False)
        # Provide a download link for the Excel file
        st.sidebar.markdown("### Download Updated Data")
        st.sidebar.write("Click the link below to download the updated data in Excel format.")
        with open("updated_data.xlsx", "rb") as file:
            # Convert the file to a base64 string
            data = file.read()
            b64 = base64.b64encode(data).decode()
            href = f'<a href="data:file/xlsx;base64,{b64}" download="updated_data.xlsx">Download XLSX</a>'

        st.sidebar.markdown(href, unsafe_allow_html=True)

    if single_number_plate:
        # Function to scrape details for a single number plate
        def find_details_single_plate(vehicle_number):
            driver = webdriver.Chrome(options=chrome_options)
            driver.get("https://www.acko.com/rto/how-to-check-vehicle-owner-details-by-number-plate/")
            WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "carNumber"))).send_keys(vehicle_number)
            driver.find_element(By.XPATH, '//button[text()="Check Now"]').click()
            try:
                element = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                    (By.XPATH, '/html/body/div[1]/div/div[3]/div/div[2]/div/div/div/div[1]/div')))
                data = element.text
            except TimeoutException:
                data = "Data not found for this number plate."

            driver.quit()
            return data

        # Scrape and display details for the single number plate
        single_plate_data = find_details_single_plate(single_number_plate)
        st.write("Details for Single Number Plate:")
        # Display single plate data in a tabular form
        if "•" in single_plate_data:
            car_model, fuel_type, registration_date_rc = single_plate_data.split("•")
            car_model = car_model.strip()
            fuel_type = fuel_type.strip()
            registration_date_rc = registration_date_rc.strip()

            single_plate_df = pd.DataFrame(
                {'Number plate': [single_number_plate], 'Car Model': [car_model], 'Fuel_type': [fuel_type],
                 'Registration_date_RC': [registration_date_rc]})
            # Display the DataFrame in the main area
            st.write("Details for Single Number Plate:")
            st.dataframe(single_plate_df)
            # Provide a download link for the Excel file
            st.markdown("### Download Result as Excel")
            st.write("Click the link below to download the result as an Excel file.")

            # Save the DataFrame to an Excel (XLSX) file
            single_plate_df.to_excel("single_plate_result.xlsx", index=False, header=True)

            # Provide a download link for the saved Excel file
            with open("single_plate_result.xlsx", "rb") as f:
                excel_data = f.read()

            b64 = base64.b64encode(excel_data).decode()
            href = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="single_plate_result.xlsx">Download Excel</a>'
            st.markdown(href, unsafe_allow_html=True)


# Create a selectbox in the sidebar for page selection
selected_page = st.sidebar.selectbox("Select a Page", ["Number Plate Extraction", "Vehicle Details Scraper"])

# Run the selected page function
if selected_page == "Number Plate Extraction":
    page_number_plate()
elif selected_page == "Vehicle Details Scraper":
    page_vehicle_details()
