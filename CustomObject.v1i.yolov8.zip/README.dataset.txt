# CustomObject > 2023-10-10 2:59am
https://universe.roboflow.com/insulatordetection/customobject-rl2ka

Provided by a Roboflow user
License: CC BY 4.0

