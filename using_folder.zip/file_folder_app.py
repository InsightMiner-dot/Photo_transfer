import os
import cv2
import numpy as np
import easyocr
import re
import pandas as pd
import streamlit as st
from tabulate import tabulate

def method_1(args):
    gray = args
    reader = easyocr.Reader(['en'])
    result = reader.readtext(gray)

    def extract_alphanumeric(text):
        return re.sub(r'[^a-zA-Z0-9]','',text)

    for detection in result:
        text = detection[1]
        confidence = detection[2]
        alphanumeric_items = [extract_alphanumeric(item[1]) for item in result]

        pattern1 = r"^[A-Za-z]{2}[0-9]{1}[A-Za-z]{3}[0-9]{4}$"
        pattern2 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{3}[0-9]{4}$"
        pattern3 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}$"
        pattern4 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{1}[0-9]{4}$"
        pattern5 = r"^[A-Z]{2}[0-9]{2}[A-Z]{3}[0-9]{4}$"
        pattern6 = r"^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$"
        pattern7 = r"^[A-Z]{2}[0-9]{2}[A-Z]{1}[0-9]{4}$"

        matching_items = []
        for item in alphanumeric_items:
            if re.search(pattern1, item) or re.search(pattern2, item) or re.search(pattern3, item) or re.search(
                    pattern4, item) or re.search(pattern5, item) or re.search(pattern6, item):
                matching_items.append(item)

        # print("Number Plate from method 1:",matching_items)
        # def write_matching_items_to_csv(image_name, matching_item):
        #     with open('write_matching_items_to_csv_1','a',newline='') as csvfile:
        #         writer = csv.writer(csvfile)
        #         for item in matching_items:
        #             writer.writerow([image_name, item])
        #
        # write_matching_items_to_csv(image_name, matching_items)
        return matching_items

def method_2(args):
        img = args
        blurred = cv2.GaussianBlur(img, (5, 5), 0)
        # Convert the image to grayscale
        gray = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)
        _, thresholded = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        kernel = np.ones((3, 3), np.uint8)
        eroded = cv2.morphologyEx(thresholded, cv2.MORPH_ERODE, kernel, iterations=1)
        dilated = cv2.morphologyEx(eroded, cv2.MORPH_DILATE, kernel, iterations=1)
        reader = easyocr.Reader(['en'])
        result = reader.readtext(dilated)

        def extract_alphanumeric(text):
            return re.sub(r'[^a-zA-Z0-9]', '', text)

        for detection in result:
            text = detection[1]
            confidence = detection[2]
            cleaned_text = extract_alphanumeric(text)
            # print(cleaned_text)

        alphanumeric_items = [extract_alphanumeric(item[1]) for item in result]

        pattern1 = r"^[A-Za-z]{2}[0-9]{1}[A-Za-z]{3}[0-9]{4}$"
        pattern2 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{3}[0-9]{4}$"
        pattern3 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}[0-9]{4}$"
        pattern4 = r"^[A-Za-z]{2}[0-9]{2}[A-Za-z]{1}[0-9]{4}$"
        pattern5 = r"^[A-Z]{2}[0-9]{2}[A-Z]{3}[0-9]{4}$"
        pattern6 = r"^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$"
        pattern7 = r"^[A-Z]{2}[0-9]{2}[A-Z]{1}[0-9]{4}$"

        matching_items = []
        for item in alphanumeric_items:
            if re.search(pattern1, item) or re.search(pattern2, item) or re.search(pattern3, item) or re.search(
                    pattern4, item) or re.search(pattern5, item) or re.search(pattern6, item) or re.search(pattern7,
                                                                                                           item):
                matching_items.append(item)

        # print("Number Plate from method 2:",matching_items)
        # def write_matching_items_to_csv(image_name, matching_item):
        #     with open('write_matching_items_to_csv_2','a',newline='') as csvfile:
        #         writer = csv.writer(csvfile)
        #         for item in matching_items:
        #             writer.writerow([image_name, item])
        #
        # write_matching_items_to_csv(image_name, matching_items)
        return matching_items
def extract_car_numbers_single_image(image):
    function_1 = method_1(image)
    function_2 = method_2(image)

    if function_1:
        result_df = pd.DataFrame({'Image Name': ['Uploaded Image'], 'Number Plates': [', '.join(function_1)]})
    else:
        result_df = pd.DataFrame({'Image Name': ['Uploaded Image'], 'Number Plates': [', '.join(function_2)]})

    return result_df

# Define a Streamlit app
def main():
    st.title("Car Number Plate Extraction")

    option = st.radio("Choose an option:", ("Single Image", "Folder of Images"))

    if option == "Single Image":
        # Upload a single image file
        uploaded_file = st.file_uploader("Upload a single image", type=["jpg", "png"])

        if uploaded_file is not None:
            image = cv2.imdecode(np.fromstring(uploaded_file.read(), np.uint8), cv2.IMREAD_COLOR)

            st.image(image, caption="Uploaded Image", use_column_width=True)

            result_df = extract_car_numbers_single_image(image)

            if not result_df.empty:
                st.subheader("Extracted Number Plates:")
                st.table(result_df)

            if st.button("Save Results"):
                if not result_df.empty:
                    result_df.to_csv('filtered_result.csv', mode='a', header=False, index=False)
                    st.success("Results saved to 'filtered_result.csv'")

    else:  # Folder of Images
        folder_path = st.text_input("Enter the path to the folder containing images:")
        if folder_path:
            image_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(('.jpg', '.png'))]

            if not image_files:
                st.warning("No image files found in the folder.")
            else:
                st.subheader("Processing Images in the Folder:")
                final_result_df = pd.DataFrame({'Image Name': [], 'Number Plates': []})

                for image_file in image_files:
                    image = cv2.imread(image_file)

                    result_df = extract_car_numbers_single_image(image)
                    final_result_df = pd.concat([final_result_df, result_df])

                filtered_df = final_result_df[final_result_df['Number Plates'] != '']

                if not filtered_df.empty:
                    st.subheader("Extracted Number Plates:")
                    st.table(filtered_df)

                if st.button("Save Results"):
                    if not filtered_df.empty:
                        filtered_df.to_csv('filtered_result.csv', mode='a', header=False, index=False)
                        st.success("Results saved to 'filtered_result.csv'")

if __name__ == "__main__":
    main()